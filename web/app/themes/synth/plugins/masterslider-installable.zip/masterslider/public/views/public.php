<?php
/**
 * Represents the view for the public-facing component of Master slider.
 *
 *
 * @package   MasterSlider
 * @author    averta [averta.net]
 * @license   LICENSE.txt
 * @link      http://masterslider.com
 * @copyright Copyright © 2014 averta
 */
?>

<!-- This file is used to markup the public facing aspect of the plugin. -->
